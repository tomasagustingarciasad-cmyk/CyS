%% APELLIDO, NOMBRE: LEGAJO 


%% PARCIAL I: CONTROL Y SISTEMAS


%% Contexto
% Estás analizando la cantidad de turnos atendidos en un consultorio médico. 
% El sistema registra diariamente el número de pacientes atendidos, generando 
% una serie temporal discreta x[k], donde cada muestra representa un día.

%% Objetivo
% El equipo de gestión solicita elaborar un reporte resumido con un *valor representativo 
% cada 10 días*, con el objetivo de facilitar el monitoreo operativo y la planificación 
% de recursos a largo plazo, eliminando las fluctuaciones diarias irrelevantes 
% para la tendencia general anual.

%% Criterio de evaluaión
% _“No se evaluará únicamente el resultado numérico, sino la calidad del razonamiento 
% técnico y la justificación de las decisiones de diseño.”_
%
% _"Cuide la presentación, escala, colores, títulos y leyendas de sus gráficos para hacerlos 
% lo más legible posible para la evaluación."_

%% Tareas a desarrollar
% Diseñar e implementar en MATLAB un script que permita reducir la serie 
% temporal original. La salida debe ser una nueva serie reducida que entregue 
% un valor representativo cada 10 días.


%% 1. Análisis Previo de los Datos
% Seleccione y aplique comandos de MATLAB para estudiar la señal original 
% y extraer la información relevante.


%% 
%------
clc 
clear
x = load('datos_turnos.txt');
%------


%%
% 
% *1.1 Justifique brevemente la elección de dichas herramientas*

% Respuesta

%%
% 
% *1.2 Explique los resultados obtenidos del análisis*

% Respuesta

%%
% 
% *1.3 Mencione qué información le resulta relevante y útil para la solución.*

% Respuesta

%% 2. Pre-Proceso
% *Proceda a realizar el tratamiento de la señal*


%% 
%-----------------------------------------
% Coloque el código de su solución aquí
%-----------------------------------------
%
%
%-----------------------------------------


%%
% 
% *2.1 Comente brevemente sobre el método elegido para el pre-procesamiento.*

% Respuesta

%%
% 
% *2.2 ¿Por qué dicha técnica es necesaria y adecuada para este problema específico? (considerando el contenido frecuencial).*

% Respuesta

%%
% 
% *2.3 Mencione los criterios utilizados para definir los parámetros del sistema de procesamiento.*

% Respuesta


%% 3. Generar serie final y gráficos
% A partir del procesamiento anterior, generar la serie final y grafiquela en 
% el tiempo y la frecuencia. Asegurarse de que la alineación temporal sea correcta 
% respecto a la señal original.


%% 
%-----------------------------------------
% Coloque el código de su solución aquí
%-----------------------------------------
%
%
%-----------------------------------------




%% 4. Validación de la respuesta
% Comparar su solución con al menos una alternativa que considere incorrecta 
% o subóptima para validar por contraste la suya. 


%% 
%-----------------------------------------
% Coloque el código de su solución aquí
%-----------------------------------------
%
%
%-----------------------------------------


%%
% 
% *4.1 Qué efectos negativos produce la alternativa subóptima (en el dominio del tiempo y/o frecuencia).*

% Respuesta

%%
% 
% *4.2 Por qué su solución propuesta mitiga estos efectos.*

% Respuesta

%% 5. Tasa de Cambio (Derivada) y Punto Fijo
% Se nos comunica que conocer solo la cantidad total de pacientes ya no es suficiente para organizar el consultorio. 
% Ahora necesitamos saber qué tan rápido sube o baja esa cantidad. Esta 
% "velocidad de cambio" de la demanda se calcula directamente usando la derivada matemática.
%%
% Como ingeniero proponés usar *representación en punto fijo* para optimizar el sistema: 
% buscamos aumentar la velocidad de cálculo y minimizar el uso de memoria.

%%
% 
% # Construya la velocidad de cambio de *su señal resultado del ejercicio anterior* en (turno/día). 
% # Analice cómo se distribuyen los valores de su señal (usando un histograma o gráfico). 
% # A partir de esa observación, determine un formato en punto fijo conveniente que ajuste para dicho rango 
% # Indique de su respuesta: N tamaño de la palabra binaria (8,16 o 32 bits) y los m bits para la parte entera, n bits para la parte fraccionaria usando la notación Qm.n (con 1 bit de signo), rango, resolución y ruido cuantización 




%%
% *Completar con los resultados obtenidos:*

%%
% * *Palabra binaria:* N 
% * *Representación*:Qm.n
% * *Rango*:
% * *Resolución:*:
% * *Ruido de cuantización*:


%% 
%-----------------------------------------
% Cálculo de la velocidad 
%-----------------------------------------
% 
%
%-----------------------------------------
% Coloque el código de su solución aquí
%-----------------------------------------
%
%
%-----------------------------------------







